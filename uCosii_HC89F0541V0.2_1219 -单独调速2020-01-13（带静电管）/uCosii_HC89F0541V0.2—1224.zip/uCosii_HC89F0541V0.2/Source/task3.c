#include "includes.h"
#include "Source\task3.h"

//extern int task4_flag_x;
//extern int task4_flag_y;

extern int task4_flag_R2;
extern int task4_flag_L2;
extern int	task4_zijian;
extern int task4_buzzer1;
extern int task4_buzzer2;
extern int task4_jiance_flag1;//�����쳣��1Ϊ��ײ��2λ��ˢ��3λ���ӣ�4λ�����5λ��ص�ѹ
extern int standby;//�Լ�ģʽ
int task3_flag1 = 1;//������
int task3_openbuzzer = 0;
int	task3_i1= 0;
void Task3(void *ppdata) reentrant
{

		ppdata = ppdata;
	while(1){


		if(task4_jiance_flag1)
		{
			task3_i1++;
			if(task4_jiance_flag1==1&&task3_i1%150==0)//�����쳣��1Ϊ��ײ
			{
				buzzer=1;
				OSTimeDly(120);
				buzzer=0;
			}
			if(task4_jiance_flag1==2)//�����쳣��2��ˢ
			{
				if(task3_i1%120 == 10||task3_i1%120 == 15||task3_i1%120 == 20)
				{
					buzzer=1;
					OSTimeDly(120);
					buzzer=0;	
				}
				
			}
			
			if(task4_jiance_flag1==3||task4_jiance_flag1==4)//�����쳣��3����4����
			{
				if(task3_i1%120 == 10||task3_i1%120 == 15)
				{
					buzzer=1;
					OSTimeDly(120);
					buzzer=0;	
				}
				if(task3_i1%120 == 70)
				{
					buzzer=1;
					OSTimeDly(240);
					buzzer=0;	
				}
				
			}	
			if(task4_jiance_flag1==5)//�����쳣��5���
			{
				if(task3_i1%120 == 10||task3_i1%120 == 15||task3_i1%120 == 20)
				{
					buzzer=1;
					OSTimeDly(120);
					buzzer=0;	
				}
				if(task3_i1%120 == 70||task3_i1%120 == 75)
				{
					buzzer=1;
					OSTimeDly(240);
					buzzer=0;	
				}
				
			}	
			
			if(task4_jiance_flag1==6&&standby==0)//�����쳣����ص�ѹ��
			{
				if(task3_i1%10 == 0)
				{
					buzzer=1;
					OSTimeDly(100);
					buzzer=0;	
				}
				
				
			}
		}

		if ( (task4_zijian==1&&task3_flag1==1&&task4_buzzer2==0) ||task3_openbuzzer==0||task4_buzzer1==1)
		{
			task3_openbuzzer++;
			task4_buzzer1 = 0;
			buzzer = 1;
			OSTimeDly(800);
			buzzer = 0;
				//task3_buzzer1(1,3000);
				task3_flag1=0;
			
		}
		if (task4_buzzer2)
		{
			buzzer = 1;
			OSTimeDly(200);
			buzzer = 0;
			task4_buzzer2 =0;
		}
		
		
		OSTimeDly(30);
		
		
		
	}  
	
	
	
	

	
	
	}

/*************************************************
	*������
	*task3_numberΪ����
	*ttask3_timerΪʱ��
	*
	****************************************************/

//void task3_buzzer1(int task3_number,int task3_timer)
//{		
//	task3_buzzer=0;
//	while(task3_buzzer<task3_number)
//	{
//		buzzer = 1;
//		OSTimeDly(task3_timer);
//		buzzer = 0;
//		task3_buzzer++;
//		OSTimeDly(task3_timer);
//	}
//	buzzer = 0;


//}
