/*
*********************************************************************************************************
*                                                uC/OS-II
*                                          The Real-Time Kernel
*
*                        (c) Copyright 1992-1998, Jean J. Labrosse, Plantation, FL
*                                           All Rights Reserved
*
*                                           MASTER INCLUDE FILE
*********************************************************************************************************
*/

/*
*********************************************************************************************************
* 
author:1949KJY
time:20191608
qq:2692377302
https://item.taobao.com/item.htm?spm=a1z10.1-c.w4004-18323443223.14.456657b1N7KwE0&id=580551386625
*                                     
*********************************************************************************************************
*/

#ifndef __INCLUDES__
#define __INCLUDES__

#include    "HC89F0541.h"
#include    "uCosii\os_cpu.h"
#include    "uCosii\os_cfg.h"
#include    "uCosii\ucos_ii.h"




#define buzzer P3_2		//������
#define G_led	 P3_0		//��LED
#define R_led	 P3_1		//��LED
#define fan	   P1_5 	//���
#define Brush  P3_3		//��ˢ
#define Wifi	P0_7 		//wifiʹ��
#define	floor	P2_1		//�ؼ�ʹ��
#define mapan P0_6		//����
sbit L1_touch = P0^5; //����
sbit R1_touch = P3^4; //�Ҵ���
sbit crash = P1^0;		//��ײ

//sbit L1_floor = P0^4; //����
//sbit C1_floor = P0^3; //�м��
//sbit R1_floor = P0^2; //�Ҽ��

sbit power = P1^4;//�����
#define power_enabled P2_0 //���ʹ��


#endif
/*
*********************************************************************************************************
* 
author:1949KJY
time:20191608
qq:2692377302
https://item.taobao.com/item.htm?spm=a1z10.1-c.w4004-18323443223.14.456657b1N7KwE0&id=580551386625
*                                     
*********************************************************************************************************
*/