#ifndef __TASK3_H
#define	__TASK3_H


//void task3_buzzer1(int task3_number,int task3_timer);


#endif