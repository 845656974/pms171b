#ifndef __TASK2_H
#define	__TASK2_H




//void task2_doubleled(int task2_led,int task2_timerled,int task2_number);//



//unsigned  int task_led_i = 0;//������

#endif