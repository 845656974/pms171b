#include "includes.h"
//#include "Source\task1.h"
#include "Source\task2.h"
#include "Source\task3.h"
/**********************************************
*ָʾ��
*
*
************************************/


extern int task4_flag_R2;
extern int task4_flag_L2;
extern int task4_led;
extern int	task4_zijian;

extern int task4_flag1;
extern int task4_flag2;
extern int task1_flag;//����
extern int task4_power1;//����־��1Ϊ��磬2Ϊ��õ�
extern int task4_power3;//�Լ��³����
extern int task4_jiance_flag1;//�����쳣��1Ϊ��ײ��2λ��ˢ��3λ���ӣ�4λ�����5λ��ص�ѹ
extern int task4_wifi_ap;//����1,����2,����0
extern int standby;//����ģʽ
int task2_openled = 0;
void Task2(void *ppdata) reentrant
{
	ppdata = ppdata;


	while(1){
		
		if(task2_openled<3)//˫������
		{
						G_led = 0;
			R_led = 0;	
			OSTimeDly(300);
			G_led = 1;
			R_led = 1;	
			OSTimeDly(300);
			task2_openled++;
		}
		if(task4_wifi_ap==1)//����ģʽ������
		{
			G_led = 0;
			R_led = 1;	
			OSTimeDly(50);
			G_led = 1;
			R_led = 1;	
			OSTimeDly(50);
		}
		if(task4_wifi_ap==2)//����ģʽ������
		{
			G_led = 0;
			R_led = 1;	
			OSTimeDly(250);
			G_led = 1;
			R_led = 1;	
			OSTimeDly(250);
		}
		if(task4_jiance_flag1&&standby==0)
		{
			G_led = 1;
			R_led = 0;	
		}
		if(standby==0&&task4_flag1==0&&task4_flag2==0&&task2_openled==3&&task4_zijian==0&&power==1&&task4_wifi_ap==0&&task4_jiance_flag1==0)//ֹͣ
		{
			G_led = 0;
			R_led = 0;	
		}
		if(standby==1)//����ģʽ
		{
			G_led = 1;
			R_led = 1;	
		}
		if(task4_flag1+task4_flag2==1&&task2_openled==3&&task1_flag<99&&task4_zijian==0&&power==1&&task4_wifi_ap==0&&task4_jiance_flag1==0)//��������
		{
			G_led = 0;
			R_led = 1;	
			OSTimeDly(400);
			G_led = 1;
			R_led = 1;	
			OSTimeDly(400);
			
			
//			task2_doubleled(2,400,1);
		}
		if(task4_flag1+task4_flag2==1&&task2_openled==3&&task1_flag>99&&task4_zijian==0&&power==1&&task4_wifi_ap==0&&task4_jiance_flag1==0)//��ת
		{
			G_led = 1;
			R_led = 0;	
			OSTimeDly(400);
			G_led = 0;
			R_led = 1;	
			OSTimeDly(400);
			
//			task2_doubleled(1,400,1);
		}
		if(task4_power1==1&&task2_openled==3&&task4_power3==0&&task4_jiance_flag1==0)//���
		{
			G_led = 1;
			R_led = 0;	
			OSTimeDly(400);
			G_led = 1;
			R_led = 1;	
				OSTimeDly(400);
		
		}
		if(task4_power1==2&&task2_openled==3&&task4_power3==0&&task4_jiance_flag1==0)//������
		{
			G_led = 0;
			R_led = 1;			
			OSTimeDly(400);
		}
	
		if ( (task4_zijian==1&&task4_flag_L2==0)  ||task4_led==1&&power==1&&task4_jiance_flag1==0)//�Լ�
		{
			
			G_led = 0;
			R_led = 0;
			OSTimeDly(100);
			G_led = 1;
			R_led = 1;
			OSTimeDly(100);
			
//			task2_doubleled(3,100,1);

		}
			
		
OSTimeDly(30);
}
	

	}
  
	

/*************************************************
	*LED����
	*task2_ledΪ���������1Ϊ�죬2λ�̣�3ȫ����4Ϊ�쳣����5Ϊ�̳�����6Ϊ2�Ƴ�����7Ϊȫ��
	*task_timerledΪʱ��
	*task2_number����
	****************************************************/
//void task2_doubleled(int task2_led,int task2_timerled,int task2_number)
//{
//	task_led_i = 0;
//	if(task2_led==3)//ȫ��
//	{
//		while(task_led_i<task2_number)
//			{
//			G_led = 0;
//			R_led = 0;
//			OSTimeDly(task2_timerled);
//			G_led = 1;
//			R_led = 1;
//			OSTimeDly(task2_timerled);
//			task_led_i++;
//			}
//		R_led = 1;
//		G_led = 1;
//		}
//	if (task2_led==2)//ֻ���̵�
//	{
//		R_led = 1;
//		while(task_led_i<task2_number)
//			{
//			G_led = 0;
//			OSTimeDly(task2_timerled);
//			G_led = 1;	
//			OSTimeDly(task2_timerled);
//			task_led_i++;
//			}
//		R_led = 1;
//		G_led = 1;
//		}
//	if (task2_led==1)//ֻ�к��
//	{
//		G_led = 1;
//		while(task_led_i<task2_number)
//			{
//			R_led = 0;
//			OSTimeDly(task2_timerled);
//			R_led = 1;	
//			OSTimeDly(task2_timerled);
//			task_led_i++;
//			}
//		R_led = 1;
//		G_led = 1;
//		}
//	
//	
//		}
//	
//	
	
	
	




